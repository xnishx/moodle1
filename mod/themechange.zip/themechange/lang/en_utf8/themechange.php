<?php

$string['themechange'] = 'themechange';

$string['modulename'] = 'changing the theme';
$string['modulenameplural'] = 'themechangeS';

$string['themechangefieldset'] = 'Custom example fieldset';
$string['themechangeintro'] = 'themechange Intro';
$string['themechangename'] = 'themechange Name';

?>
