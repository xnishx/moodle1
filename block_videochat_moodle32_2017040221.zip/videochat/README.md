# Moodle-blocks_videochat

The Video chat block allows users in same course to have video chat user WebRTC. It supports openandtalk.com and other video chat service.

##To Install
1. Copy the progress directory to the blocks directory of your Moodle instance
2. Visit the notifications page 

##Once the Video chat block is installed, you can use it in a course as follows.

1. Turn editing on
2. Add the Video chat block to your page

**Note**: you might need to allow popup window in your browser to use this block.
