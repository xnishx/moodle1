To install:
 1. Copy the 'heatmap' folder to the blocks folder.
 2. Visit the Notifications page (Site Administration -> Notifications)

The block can then be added from the Blocks list when Editing is turned on.
