$(function(){
	if ($('#exalib-categories').length) {
		var easytree = $('#exalib-categories').easytree();
	}
});
